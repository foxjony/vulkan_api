// Vulkan compute-only шаблон
// https://chatgpt.com/share/69d19755-dfb0-8333-a646-0b79f4848b67

// C:\VulkanSDK\1.4.341.1\Bin\glslc.exe shaders\comp.comp -o shaders\comp.spv

#define GLFW_INCLUDE_VULKAN
#include <GLFW/glfw3.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define N 1000000

VkInstance instance;
VkPhysicalDevice physicalDevice;
VkDevice device;
VkQueue queue;
uint32_t queueFamilyIndex;

VkBuffer bufferA, bufferB;
VkDeviceMemory memoryA, memoryB;

VkDescriptorSetLayout descriptorSetLayout;
VkDescriptorPool descriptorPool;
VkDescriptorSet descriptorSet;

VkPipelineLayout pipelineLayout;
VkPipeline pipeline;

VkCommandPool commandPool;
VkCommandBuffer commandBuffer;

VkFence fence;

// ---------- helpers ----------
uint32_t findMemoryType(uint32_t typeFilter, VkMemoryPropertyFlags properties) {
    VkPhysicalDeviceMemoryProperties memProperties;
    vkGetPhysicalDeviceMemoryProperties(physicalDevice, &memProperties);

    for (uint32_t i = 0; i < memProperties.memoryTypeCount; i++) {
        if ((typeFilter & (1 << i)) &&
            (memProperties.memoryTypes[i].propertyFlags & properties) == properties) {
            return i;
        }
    }
    printf("failed to find memory type\n");
    exit(1);
}

void createBuffer(VkDeviceSize size, VkBuffer* buffer, VkDeviceMemory* memory) {
    VkBufferCreateInfo bufferInfo = {};
    bufferInfo.sType = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO;
    bufferInfo.size = size;
    bufferInfo.usage = VK_BUFFER_USAGE_STORAGE_BUFFER_BIT;
    bufferInfo.sharingMode = VK_SHARING_MODE_EXCLUSIVE;

    vkCreateBuffer(device, &bufferInfo, NULL, buffer);

    VkMemoryRequirements memRequirements;
    vkGetBufferMemoryRequirements(device, *buffer, &memRequirements);

    VkMemoryAllocateInfo allocInfo = {};
    allocInfo.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
    allocInfo.allocationSize = memRequirements.size;
    allocInfo.memoryTypeIndex = findMemoryType(
        memRequirements.memoryTypeBits,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);

    vkAllocateMemory(device, &allocInfo, NULL, memory);
    vkBindBufferMemory(device, *buffer, *memory, 0);
}

uint32_t* readFile(const char* filename, uint32_t* size) {
    FILE* f;
    fopen_s(&f, filename, "rb");

    fseek(f, 0, SEEK_END);
    *size = ftell(f);
    rewind(f);

    uint32_t* data = malloc(*size);
    fread(data, 1, *size, f);
    fclose(f);
    return data;
}

VkShaderModule createShaderModule(const uint32_t* code, uint32_t size) {
    VkShaderModuleCreateInfo info = {};
    info.sType = VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO;
    info.codeSize = size;
    info.pCode = code;

    VkShaderModule module;
    vkCreateShaderModule(device, &info, NULL, &module);
    return module;
}

// ---------- init ----------
void initVulkan() {
    // instance
    VkApplicationInfo app = {};
    app.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    app.apiVersion = VK_API_VERSION_1_1;

    VkInstanceCreateInfo create = {};
    create.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    create.pApplicationInfo = &app;

    vkCreateInstance(&create, NULL, &instance);

    // physical device
    uint32_t count;
    vkEnumeratePhysicalDevices(instance, &count, NULL);
    VkPhysicalDevice devices[4];
    vkEnumeratePhysicalDevices(instance, &count, devices);
    physicalDevice = devices[0];

    // queue family
    uint32_t qCount;
    vkGetPhysicalDeviceQueueFamilyProperties(physicalDevice, &qCount, NULL);
    VkQueueFamilyProperties qProps[8];
    vkGetPhysicalDeviceQueueFamilyProperties(physicalDevice, &qCount, qProps);

    for (uint32_t i = 0; i < qCount; i++) {
        if (qProps[i].queueFlags & VK_QUEUE_COMPUTE_BIT) {
            queueFamilyIndex = i;
            break;
        }
    }

    float priority = 1.0f;
    VkDeviceQueueCreateInfo qInfo = {};
    qInfo.sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO;
    qInfo.queueFamilyIndex = queueFamilyIndex;
    qInfo.queueCount = 1;
    qInfo.pQueuePriorities = &priority;

    VkDeviceCreateInfo devInfo = {};
    devInfo.sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO;
    devInfo.queueCreateInfoCount = 1;
    devInfo.pQueueCreateInfos = &qInfo;

    vkCreateDevice(physicalDevice, &devInfo, NULL, &device);
    vkGetDeviceQueue(device, queueFamilyIndex, 0, &queue);

    // buffers
    createBuffer(sizeof(int) * N, &bufferA, &memoryA);
    createBuffer(sizeof(int) * N, &bufferB, &memoryB);

    // fill A
    int* data;
    vkMapMemory(device, memoryA, 0, sizeof(int) * N, 0, (void**)&data);
    for (int i = 0; i < N; i++) data[i] = i + 1;
    vkUnmapMemory(device, memoryA);

    // descriptor layout
    VkDescriptorSetLayoutBinding bindings[2] = {};

    bindings[0].binding = 0;
    bindings[0].descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
    bindings[0].descriptorCount = 1;
    bindings[0].stageFlags = VK_SHADER_STAGE_COMPUTE_BIT;

    bindings[1].binding = 1;
    bindings[1].descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
    bindings[1].descriptorCount = 1;
    bindings[1].stageFlags = VK_SHADER_STAGE_COMPUTE_BIT;

    VkDescriptorSetLayoutCreateInfo layoutInfo = {};
    layoutInfo.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO;
    layoutInfo.bindingCount = 2;
    layoutInfo.pBindings = bindings;

    vkCreateDescriptorSetLayout(device, &layoutInfo, NULL, &descriptorSetLayout);

    // descriptor pool
    VkDescriptorPoolSize poolSize = {};
    poolSize.type = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
    poolSize.descriptorCount = 2;

    VkDescriptorPoolCreateInfo poolInfo = {};
    poolInfo.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO;
    poolInfo.maxSets = 1;
    poolInfo.poolSizeCount = 1;
    poolInfo.pPoolSizes = &poolSize;

    vkCreateDescriptorPool(device, &poolInfo, NULL, &descriptorPool);

    // descriptor set
    VkDescriptorSetAllocateInfo allocInfo = {};
    allocInfo.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO;
    allocInfo.descriptorPool = descriptorPool;
    allocInfo.descriptorSetCount = 1;
    allocInfo.pSetLayouts = &descriptorSetLayout;

    vkAllocateDescriptorSets(device, &allocInfo, &descriptorSet);

    VkDescriptorBufferInfo bufA = {bufferA, 0, sizeof(int) * N};
    VkDescriptorBufferInfo bufB = {bufferB, 0, sizeof(int) * N};

    VkWriteDescriptorSet writes[2] = {};

    writes[0].sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
    writes[0].dstSet = descriptorSet;
    writes[0].dstBinding = 0;
    writes[0].descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
    writes[0].descriptorCount = 1;
    writes[0].pBufferInfo = &bufA;

    writes[1].sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
    writes[1].dstSet = descriptorSet;
    writes[1].dstBinding = 1;
    writes[1].descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
    writes[1].descriptorCount = 1;
    writes[1].pBufferInfo = &bufB;

    vkUpdateDescriptorSets(device, 2, writes, 0, NULL);

    // pipeline
    uint32_t size;
    uint32_t* code = readFile("shaders/comp.spv", &size);

    VkShaderModule shader = createShaderModule(code, size);

    VkPipelineLayoutCreateInfo pl = {};
    pl.sType = VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO;
    pl.setLayoutCount = 1;
    pl.pSetLayouts = &descriptorSetLayout;

    vkCreatePipelineLayout(device, &pl, NULL, &pipelineLayout);

    VkComputePipelineCreateInfo cp = {};
    cp.sType = VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO;
    cp.stage.sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    cp.stage.stage = VK_SHADER_STAGE_COMPUTE_BIT;
    cp.stage.module = shader;
    cp.stage.pName = "main";
    cp.layout = pipelineLayout;

    vkCreateComputePipelines(device, VK_NULL_HANDLE, 1, &cp, NULL, &pipeline);

    // command
    VkCommandPoolCreateInfo pool = {};
    pool.sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;
    pool.queueFamilyIndex = queueFamilyIndex;

    vkCreateCommandPool(device, &pool, NULL, &commandPool);

    VkCommandBufferAllocateInfo cmdAlloc = {};
    cmdAlloc.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;
    cmdAlloc.commandPool = commandPool;
    cmdAlloc.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    cmdAlloc.commandBufferCount = 1;

    vkAllocateCommandBuffers(device, &cmdAlloc, &commandBuffer);

    // record
    VkCommandBufferBeginInfo begin = {};
    begin.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;

    vkBeginCommandBuffer(commandBuffer, &begin);

    vkCmdBindPipeline(commandBuffer, VK_PIPELINE_BIND_POINT_COMPUTE, pipeline);
    vkCmdBindDescriptorSets(commandBuffer, VK_PIPELINE_BIND_POINT_COMPUTE,
                            pipelineLayout, 0, 1, &descriptorSet, 0, NULL);

    vkCmdDispatch(commandBuffer, (N + 63) / 64, 1, 1);

    vkEndCommandBuffer(commandBuffer);

    // fence
    VkFenceCreateInfo f = {};
    f.sType = VK_STRUCTURE_TYPE_FENCE_CREATE_INFO;
    vkCreateFence(device, &f, NULL, &fence);
}

void run() {
    VkSubmitInfo submit = {};
    submit.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;
    submit.commandBufferCount = 1;
    submit.pCommandBuffers = &commandBuffer;

    vkQueueSubmit(queue, 1, &submit, fence);
    vkWaitForFences(device, 1, &fence, VK_TRUE, UINT64_MAX);
}

void readBack() {
    int* data;
    vkMapMemory(device, memoryB, 0, sizeof(int) * N, 0, (void**)&data);

    for (uint32_t i = 0; i < 10; i++) {printf("%d -> %d\n", i + 1, data[i]);}
    for (uint32_t i = 999990; i < 1000000; i++) {printf("%d -> %d\n", i + 1, data[i]);}

    vkUnmapMemory(device, memoryB);
}

int main() {
    initVulkan();
    run();
    readBack();
    getchar();
    return 0;
}
